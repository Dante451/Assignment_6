# Assignment 6

## Description
Using classes and enums to determine mortgage payment options for clients.

## Author
[Your name]

## Assignment
Assignment 6: Defining and using classes.
Created Enum
Created Class
Created Unit Test Class
Updated Client program
{this should be more detailed.}